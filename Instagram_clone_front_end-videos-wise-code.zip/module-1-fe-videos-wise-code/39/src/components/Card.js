import React from 'react'

const Card = () => {
    return (
        <div>
            <div className="card shadow">
                <div className="card-body px-2">
                    Hello
                </div>
            </div>
        </div>
    )
}

export default Card