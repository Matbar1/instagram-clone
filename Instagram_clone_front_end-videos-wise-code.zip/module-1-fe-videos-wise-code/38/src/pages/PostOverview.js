import React from 'react'
import Card from '../components/Card'
const PostOverview = () => {
  return (
    <div>
        <Card />
        <Card />
        <Card />
    </div>
  )
}

export default PostOverview